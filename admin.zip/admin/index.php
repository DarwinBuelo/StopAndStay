<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <title>Lakbay Bikol | Admin</title>
    <style>
        .imageThumb2 {
            max-height: 75px;
            max-width: 75px;
            border: 2px solid;
            padding: 1px;
            cursor: pointer;
        }
    </style>
</head>
<?php include_once( "header.php"); include_once( "../includes/db2.php"); session_start(); // if(isset()) ?>
<!-- ============================================================== -->
<!-- wrapper  -->
<!-- ============================================================== -->
<div class="dashboard-wrapper">
    <div class="influence-profile">
        <div class="container-fluid dashboard-content ">
            <!-- ============================================================== -->
            <!-- pageheader -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h3 class="mb-2">Influencer Profile </h3>
                        <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#" class="breadcrumb-link">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Influencer Profile Template</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end pageheader -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- content -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- end profile -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- campaign data -->
            <!-- ============================================================== -->
            <div class="col-xl-12 col-lg-12 col-md-7 col-sm-12 col-12">
                <!-- ============================================================== -->
                <!-- campaign tab one -->
                <!-- ============================================================== -->
                <div class="influence-profile-content pills-regular">
                    <ul class="nav nav-pills mb-3 nav-justified" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-campaign-tab" data-toggle="pill" href="#tspot" role="tab" aria-controls="pills-campaign" aria-selected="true">Tourist Spots</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-packages-tab" data-toggle="pill" href="#events" role="tab" aria-controls="pills-packages" aria-selected="false">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-review-tab" data-toggle="pill" href="#agency" role="tab" aria-controls="pills-review" aria-selected="false">Guides/Agencies</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-packages-tab" data-toggle="pill" href="#entities" role="tab" aria-controls="pills-packages" aria-selected="false">Related Entities</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-msg-tab" data-toggle="pill" href="#feed" role="tab" aria-controls="pills-msg" aria-selected="false">Feed</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <!-- =======================   TPOST PILL  ================================= -->
                        <div class="tab-pane fade show active" id="tspot" role="tabpanel" aria-labelledby="pills-campaign-tab">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="section-block">
                                        <h3 class="section-title">Tourist Spots</h3>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h1 class="mb-1">
                                                             <?php
                                                            $sql="SELECT COUNT(id)as num from tbl_touristspot where attraction_type=0";
                                                            $res=mysqli_fetch_assoc(mysqli_query($conn,$sql));
                                                            echo $res['num'];
                                                            ?>
                                                                </h1>
                                            <p>Tourist Spots</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h2 class="mb-1">
                                                                    <?php
                                                            $sql="SELECT * from tbl_touristspot where attraction_rating<=5 ORDER BY attraction_rating desc";
                                                            $res=mysqli_query($conn,$sql);
                                                            $row=mysqli_fetch_array($res);
                                                            echo $row['attraction_name'];
                                                            ?>
                                                                </h2>
                                            <p>Top Rated</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h1 class="mb-1">
                                                                    <?php
                                                            date_default_timezone_set("Asia/Bangkok");
                                                            $today = date('Y-m-d h:i:s');
                                                            $sql="SELECT * from tbl_touristspot where craeted_at='.$today.'";
                                                            $res=mysqli_fetch_assoc(mysqli_query($conn,$sql));
                                                            echo $res['attraction_name'];
                                                            ?>
                                                                </h1>
                                            <p>Newest</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h1 class="mb-1">
                                                                    <?php
                                                            date_default_timezone_set("Asia/Bangkok");
                                                            $today = date('Y-m-d h:i:s');
                                                            $sql="SELECT * from tbl_touristspot where updated_at='.$today.'";
                                                            $res=mysqli_fetch_assoc(mysqli_query($conn,$sql));
                                                            if($res)
                                                            {
                                                                echo $res['attraction_name'];
                                                            }
                                                            else
                                                                echo "None";
                                                            ?>
                                                                </h1>
                                            <p>Last Updated</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="section-block">
                                <h3 class="section-title">Categories:</h3>
                            </div>
                            <div class="accrodion-regular">
                                <div id="accordion4">
                                    <div class="card bg-success">
                                        <div class="card-header" id="headingTen">
                                            <h5 class="mb-0">
                                                                    <button class="btn btn-link text-white collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                                                        <span class="fas fa-angle-down mr-3"></span>Nature and Tourism
                                               
                                                                    </button>
                                                                </h5>
                                        </div>
                                        <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordion4" style="">
                                            <div class="card-body">
                                                <!-- BODY OF NATURE AND TOURISM HERE -->
                                                <table>
                                                        <tr>
                                                            <?php $count=0; $sql="SELECT * from tbl_touristspot where attraction_category='Nature Tourism'" ; 
                                                            $res=mysqli_query($conn,$sql); 
                                                            while($row=mysqli_fetch_array($res)) 
                                                                { if($count%4==0) 
                                                                    { echo '
                                                                            </tr>
                                                                            <tr>'; } echo '
                                                                                <td style="width:25%; height:25%;">'; echo '
                                                                                    <div class="col-xl-12 col-l-12 col-md-12 col-sm-12 col-xs-12">
                                                                                        <div class="card card-figure">
                                                                                            <figure class="figure">
                                                                                                <div class="figure-img">
                                                                                                    <img class="img-fluid" src="../../lakbaybikol-api/images/'; echo $row[ 'attraction_image']. '"'; echo 'alt="'.$row[ 'attraction_name']. '">
                                                                                                        <div class="figure-tools">
                                                                                                            <a href="#" class="tile tile-circle tile-sm mr-auto">
                                                                                                                <span class="oi-data-transfer-download"></span>
                                                                                                            </a>
                                                                                                            <span class="badge badge-danger">'.$row[ 'attraction_name']. '</span>
                                                                                                        </div>
                                                                                                        <div class="figure-action">
                                                                                                            <a href="tspot_view_item.php?item='.$row[ 'id']; echo '" class="btn btn-block btn-sm btn-primary">View</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <figcaption class="figure-caption">
                                                                                                        <div class="rating-star">'; if($row[ 'attraction_total_reviews']!=0) { $ratenum=ceil($row[ 'attraction_total_rating']/$row[ 'attraction_total_reviews']); $ratenumless=5-$ratenum; for($i=0;$i<$ratenum;$i++) { echo '
                                                                                                            <i class="fas fa-star"></i>'; } for($i=0;$i<$ratenumless;$i++) { echo '
                                                                                                            <i class="far fa-star"></i>'; } } else { for($i=0;$i <5;$i++) { echo '
                                                                                                                <i class="far fa-star"></i>'; } } echo '
                                                                                                            </div>'; echo '
                                                                                                            <p class="text-muted mb-0">'.$row[ 'attraction_total_reviews']. ' Reviews</p>
                                                                                                        </figcaption>
                                                                                                    </figure>
                                                                                                </div>'; echo '
                                                                                            </td>'; $count+=1; } ?>
                                                        </tr>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card bg-brand ">
                                        <div class="card-header" id="headingEleven">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                                                    <span class="fas fa-angle-down mr-3"></span>Sun and Beach Tourism
                         
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseEleven" class="collapse" aria-labelledby="headingEleven" data-parent="#accordion4">
                                            <div class="card-body">
                                                <!-- body of sun and beach tourism -->
                                                <div class="col-xl-12">
                                                    <table>
                                                        <tr>
                                                            <?php $count=0; $sql="SELECT * from tbl_touristspot where attraction_category='Sun and Beach Tourism'" ; $res=mysqli_query($conn,$sql); while($row=mysqli_fetch_array($res)) { if($count%4==0) { echo '
                                                                            </tr>
                                                                            <tr>'; } echo '
                                                                                <td style="width:25%; height:25%;">'; echo '
                                                                                    <div class="col-xl-12 col-l-12 col-md-12 col-sm-12 col-xs-12">
                                                                                        <div class="card card-figure">
                                                                                            <figure class="figure">
                                                                                                <div class="figure-img">
                                                                                                    <img class="img-fluid" src="../../lakbaybikol-api/images/'; echo $row[ 'attraction_image']. '"'; echo 'alt="'.$row[ 'attraction_name']. '">
                                                                                                        <div class="figure-tools">
                                                                                                            <a href="#" class="tile tile-circle tile-sm mr-auto">
                                                                                                                <span class="oi-data-transfer-download"></span>
                                                                                                            </a>
                                                                                                            <span class="badge badge-danger">'.$row[ 'attraction_name']. '</span>
                                                                                                        </div>
                                                                                                        <div class="figure-action">
                                                                                                            <a href="tspot_view_item.php?item='.$row[ 'id']; echo '" class="btn btn-block btn-sm btn-primary">View</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <figcaption class="figure-caption">
                                                                                                        <div class="rating-star">'; if($row[ 'attraction_total_reviews']!=0) { $ratenum=ceil($row[ 'attraction_total_rating']/$row[ 'attraction_total_reviews']); $ratenumless=5-$ratenum; for($i=0;$i<$ratenum;$i++) { echo '
                                                                                                            <i class="fas fa-star"></i>'; } for($i=0;$i<$ratenumless;$i++) { echo '
                                                                                                            <i class="far fa-star"></i>'; } } else { for($i=0;$i <5;$i++) { echo '
                                                                                                                <i class="far fa-star"></i>'; } } echo '
                                                                                                            </div>'; echo '
                                                                                                            <p class="text-muted mb-0">'.$row[ 'attraction_total_reviews']. ' </p>
                                                                                                        </figcaption>
                                                                                                    </figure>
                                                                                                </div>'; echo '
                                                                                            </td>'; $count+=1; } ?>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <div class="card bg-primary">
                                        <div class="card-header" id="headingTwelve">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link collapsed text-white" data-toggle="collapse" data-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
                                                    <span class="fas fa-angle-down mr-3"></span>Cultural/Historical Tourism
                                                    
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseTwelve" class="collapse" aria-labelledby="headingTwelve" data-parent="#accordion4">
                                            <div class="card-body">
                                                <!-- body of Cultural and historical tourism -->
                                                <table>
                                                        <tr>
                                                            <?php $count=0; $sql="SELECT * from tbl_touristspot where attraction_category='Cultural/Historical Tourism'" ; $res=mysqli_query($conn,$sql); while($row=mysqli_fetch_array($res)) { if($count%4==0) { echo '
                                                                            </tr>
                                                                            <tr>'; } echo '
                                                                                <td style="width:25%; height:25%;">'; echo '
                                                                                    <div class="col-xl-12 col-l-12 col-md-12 col-sm-12 col-xs-12">
                                                                                        <div class="card card-figure">
                                                                                            <figure class="figure">
                                                                                                <div class="figure-img">
                                                                                                    <img class="img-fluid" src="../../lakbaybikol-api/images/'; echo $row[ 'attraction_image']. '"'; echo 'alt="'.$row[ 'attraction_name']. '">
                                                                                                        <div class="figure-tools">
                                                                                                            <a href="#" class="tile tile-circle tile-sm mr-auto">
                                                                                                                <span class="oi-data-transfer-download"></span>
                                                                                                            </a>
                                                                                                            <span class="badge badge-danger">'.$row[ 'attraction_name']. '</span>
                                                                                                        </div>
                                                                                                        <div class="figure-action">
                                                                                                            <a href="tspot_view_item.php?item='.$row[ 'id']; echo '" class="btn btn-block btn-sm btn-primary">View</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <figcaption class="figure-caption">
                                                                                                        <div class="rating-star">'; if($row[ 'attraction_total_reviews']!=0) { $ratenum=ceil($row[ 'attraction_total_rating']/$row[ 'attraction_total_reviews']); $ratenumless=5-$ratenum; for($i=0;$i<$ratenum;$i++) { echo '
                                                                                                            <i class="fas fa-star"></i>'; } for($i=0;$i<$ratenumless;$i++) { echo '
                                                                                                            <i class="far fa-star"></i>'; } } else { for($i=0;$i <5;$i++) { echo '
                                                                                                                <i class="far fa-star"></i>'; } } echo '
                                                                                                            </div>'; echo '
                                                                                                            <p class="text-muted mb-0">'.$row[ 'attraction_total_reviews']. 'Reviews </p>
                                                                                                        </figcaption>
                                                                                                    </figure>
                                                                                                </div>'; echo '
                                                                                            </td>'; $count+=1; } ?>
                                                        </tr>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card bg-customleisure">
                                        <div class="card-header" id="headingTwelve">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link collapsed text-white" data-toggle="collapse" data-target="#collapseTwelve1" aria-expanded="false" aria-controls="collapseTwelve">
                                                    <span class="fas fa-angle-down mr-3"></span>Leisure and Entertainment Tourism
             
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseTwelve1" class="collapse" aria-labelledby="headingTwelve1" data-parent="#accordion4">
                                            <div class="card-body">
                                                <!-- body of Leisure and Entertainment Tourism -->
                                                <table>
                                                        <tr>
                                                            <?php $count=0; $sql="SELECT * from tbl_touristspot where attraction_category='Leisure and Entertainment Tourism'" ; $res=mysqli_query($conn,$sql); while($row=mysqli_fetch_array($res)) { if($count%4==0) { echo '
                                                                            </tr>
                                                                            <tr>'; } echo '
                                                                                <td style="width:25%; height:25%;">'; echo '
                                                                                    <div class="col-xl-12 col-l-12 col-md-12 col-sm-12 col-xs-12">
                                                                                        <div class="card card-figure">
                                                                                            <figure class="figure">
                                                                                                <div class="figure-img">
                                                                                                    <img class="img-fluid" src="../../lakbaybikol-api/images/'; echo $row[ 'attraction_image']. '"'; echo 'alt="'.$row[ 'attraction_name']. '">
                                                                                                        <div class="figure-tools">
                                                                                                            <a href="#" class="tile tile-circle tile-sm mr-auto">
                                                                                                                <span class="oi-data-transfer-download"></span>
                                                                                                            </a>
                                                                                                            <span class="badge badge-danger">'.$row[ 'attraction_name']. '</span>
                                                                                                        </div>
                                                                                                        <div class="figure-action">
                                                                                                            <a href="tspot_view_item.php?item='.$row[ 'id']; echo '" class="btn btn-block btn-sm btn-primary">View</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <figcaption class="figure-caption">
                                                                                                        <div class="rating-star">'; if($row[ 'attraction_total_reviews']!=0) { $ratenum=ceil($row[ 'attraction_total_rating']/$row[ 'attraction_total_reviews']); $ratenumless=5-$ratenum; for($i=0;$i<$ratenum;$i++) { echo '
                                                                                                            <i class="fas fa-star"></i>'; } for($i=0;$i<$ratenumless;$i++) { echo '
                                                                                                            <i class="far fa-star"></i>'; } } else { for($i=0;$i <5;$i++) { echo '
                                                                                                                <i class="far fa-star"></i>'; } } echo '
                                                                                                            </div>'; echo '
                                                                                                            <p class="text-muted mb-0">'.$row[ 'attraction_total_reviews']. 'Reviews </p>
                                                                                                        </figcaption>
                                                                                                    </figure>
                                                                                                </div>'; echo '
                                                                                            </td>'; $count+=1; } ?>
                                                        </tr>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end content -->
                            <!-- ============================================================== -->
                            
                            <!-- ============================================================== -->
                            <!-- end wrapper -->
                            <!-- ============================================================== -->
                        <!-- =======================  END OF TPOST PILL  ================================= -->
                        <!-- =======================   EVENT PILL  ================================= -->
                        <div class="tab-pane fade show " id="events" role="tabpanel" aria-labelledby="pills-campaign-tab">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="section-block">
                                        <h3 class="section-title">Events</h3>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h1 class="mb-1">
                                                             <?php
                                                            $sql="SELECT COUNT(id)as num from tbl_touristspot where attraction_type=0";
                                                            $res=mysqli_fetch_assoc(mysqli_query($conn,$sql));
                                                            echo $res['num'];
                                                            ?>
                                                                </h1>
                                            <p>Tourist Spots</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h2 class="mb-1">
                                                                    <?php
                                                            $sql="SELECT * from tbl_touristspot where attraction_rating<=5 ORDER BY attraction_rating desc";
                                                            $res=mysqli_query($conn,$sql);
                                                            $row=mysqli_fetch_array($res);
                                                            echo $row['attraction_name'];
                                                            ?>
                                                                </h2>
                                            <p>Top Rated</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h1 class="mb-1">
                                                                    <?php
                                                            date_default_timezone_set("Asia/Bangkok");
                                                            $today = date('Y-m-d h:i:s');
                                                            $sql="SELECT * from tbl_touristspot where craeted_at='.$today.'";
                                                            $res=mysqli_fetch_assoc(mysqli_query($conn,$sql));
                                                            echo $res['attraction_name'];
                                                            ?>
                                                                </h1>
                                            <p>Newest</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h1 class="mb-1">
                                                                    <?php
                                                            date_default_timezone_set("Asia/Bangkok");
                                                            $today = date('Y-m-d h:i:s');
                                                            $sql="SELECT * from tbl_touristspot where updated_at='.$today.'";
                                                            $res=mysqli_fetch_assoc(mysqli_query($conn,$sql));
                                                            if($res)
                                                            {
                                                                echo $res['attraction_name'];
                                                            }
                                                            else
                                                                echo "None";
                                                            ?>
                                                                </h1>
                                            <p>Last Updated</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="section-block">
                                <h3 class="section-title">Categories:</h3>
                            </div>
                            <div class="accrodion-regular">
                                <div id="accordion4">
                                    <div class="card bg-success">
                                        <div class="card-header" id="headingTen">
                                            <h5 class="mb-0">
                                                                    <button class="btn btn-link text-white collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                                                        <span class="fas fa-angle-down mr-3"></span>Nature and Tourism
                                               
                                                                    </button>
                                                                </h5>
                                        </div>
                                        <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordion4" style="">
                                            <div class="card-body">
                                                <!-- BODY OF NATURE AND TOURISM HERE -->
                                                <?php $sql="SELECT * from tbl_touristspot where attraction_category='Nature and Tourism'" ; $res=mysqli_query($conn,$sql); while($row=mysqli_fetch_array($res)) { } ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card bg-brand ">
                                        <div class="card-header" id="headingEleven">
                                            <h5 class="mb-0">
                                                                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                                                                        <span class="fas fa-angle-down mr-3"></span>Sun and Beach Tourism
                                             
                                                                    </button>
                                                                </h5>
                                        </div>
                                        <div id="collapseEleven" class="collapse" aria-labelledby="headingEleven" data-parent="#accordion4">
                                            <div class="card-body">
                                                <!-- body of sun and beach tourism -->
                                                <div class="col-xl-12">
                                                    <table>
                                                        <tr>
                                                            <?php $count=0; $sql="SELECT * from tbl_touristspot where attraction_category='Sun and Beach Tourism'" ; $res=mysqli_query($conn,$sql); while($row=mysqli_fetch_array($res)) { if($count%4==0) { echo '
                                                                            </tr>
                                                                            <tr>'; } echo '
                                                                                <td style="width:25%; height:25%;">'; echo '
                                                                                    <div class="col-xl-12 col-l-12 col-md-12 col-sm-12 col-xs-12">
                                                                                        <div class="card card-figure">
                                                                                            <figure class="figure">
                                                                                                <div class="figure-img">
                                                                                                    <img class="img-fluid" src="../../lakbaybikol-api/images/'; echo $row[ 'attraction_image']. '"'; echo 'alt="'.$row[ 'attraction_name']. '">
                                                                                                        <div class="figure-tools">
                                                                                                            <a href="#" class="tile tile-circle tile-sm mr-auto">
                                                                                                                <span class="oi-data-transfer-download"></span>
                                                                                                            </a>
                                                                                                            <span class="badge badge-danger">'.$row[ 'attraction_name']. '</span>
                                                                                                        </div>
                                                                                                        <div class="figure-action">
                                                                                                            <a href="tspot_view_item.php?item='.$row[ 'id']; echo '" class="btn btn-block btn-sm btn-primary">View</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <figcaption class="figure-caption">
                                                                                                        <div class="rating-star">'; if($row[ 'attraction_total_reviews']!=0) { $ratenum=ceil($row[ 'attraction_total_rating']/$row[ 'attraction_total_reviews']); $ratenumless=5-$ratenum; for($i=0;$i<$ratenum;$i++) { echo '
                                                                                                            <i class="fas fa-star"></i>'; } for($i=0;$i<$ratenumless;$i++) { echo '
                                                                                                            <i class="far fa-star"></i>'; } } else { for($i=0;$i <5;$i++) { echo '
                                                                                                                <i class="far fa-star"></i>'; } } echo '
                                                                                                            </div>'; echo '
                                                                                                            <p class="text-muted mb-0">'.$row[ 'attraction_total_reviews']. ' </p>
                                                                                                        </figcaption>
                                                                                                    </figure>
                                                                                                </div>'; echo '
                                                                                            </td>'; $count+=1; } ?>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <div class="card bg-primary">
                                        <div class="card-header" id="headingTwelve">
                                            <h5 class="mb-0">
                                                                                <button class="btn btn-link collapsed text-white" data-toggle="collapse" data-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
                                                                                    <span class="fas fa-angle-down mr-3"></span>Cultural/Historical Tourism
                                             
                                                                                </button>
                                                                            </h5>
                                        </div>
                                        <div id="collapseTwelve" class="collapse" aria-labelledby="headingTwelve" data-parent="#accordion4">
                                            <div class="card-body">
                                                <!-- body of Cultural and historical tourism -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card bg-customleisure">
                                        <div class="card-header" id="headingTwelve">
                                            <h5 class="mb-0">
                                                                                <button class="btn btn-link collapsed text-white" data-toggle="collapse" data-target="#collapseTwelve1" aria-expanded="false" aria-controls="collapseTwelve">
                                                                                    <span class="fas fa-angle-down mr-3"></span>Leisure and Entertainment Tourism
                                             
                                                                                </button>
                                                                            </h5>
                                        </div>
                                        <div id="collapseTwelve1" class="collapse" aria-labelledby="headingTwelve1" data-parent="#accordion4">
                                            <div class="card-body">
                                                <!-- body of Leisure and Entertainment Tourism -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        <!-- =======================   END OF EVENT PILL  ================================= -->
                    </div>
                </div>
            </div>
                        <!-- ============================================================== -->
                        <!-- end main wrapper -->
                        <!-- ============================================================== -->
                        <!-- Optional JavaScript -->
                        <!-- jquery 3.3.1  -->
                        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
                        <!-- bootstap bundle js -->
                        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
                        <!-- slimscroll js -->
                        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
                        <!-- main js -->
                        <script src="assets/libs/js/main-js.js"></script>
                        </body>

</html>